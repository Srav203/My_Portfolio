import React from 'react';
import { motion } from 'framer-motion';
import { Github, Linkedin, Mail, ExternalLink, Code, Briefcase, User, ChevronDown } from 'lucide-react';

function App() {
  const fadeIn = {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.6 }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 text-white">
      {/* Hero Section */}
      <motion.header 
        className="min-h-screen flex flex-col items-center justify-center relative px-4"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1 }}
      >
        <motion.div 
          className="text-center"
          {...fadeIn}
        >
          <motion.div 
            className="mb-8 relative inline-block"
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <div className="w-48 h-48 md:w-56 md:h-56 rounded-full overflow-hidden border-4 border-blue-400 relative">
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-blue-400/20 to-purple-500/20"
                animate={{
                  rotate: [0, 360],
                }}
                transition={{
                  duration: 8,
                  repeat: Infinity,
                  ease: "linear"
                }}
              />
            <img
              src="https://www.dropbox.com/scl/fi/ep4vfdp9vj1iobjpxu847/my-passport-size-photo.jpg?rlkey=jeo9rj0pbw178ouh5rm6atnzd&raw=1"
              alt=""
              className="w-full h-full object-cover"
              />
            </div>
            <motion.div
              className="absolute -inset-1 rounded-full bg-gradient-to-r from-blue-500 to-purple-500 opacity-30 blur-lg -z-10"
              animate={{
                scale: [1, 1.1, 1],
                opacity: [0.3, 0.5, 0.3],
              }}
              transition={{
                duration: 4,
                repeat: Infinity,
                ease: "easeInOut"
              }}
            />
          </motion.div>
          <h1 className="text-6xl font-bold mb-6">Sravani Vemuri</h1>
          <h2 className="text-2xl text-gray-300 mb-8">Aspiring Python Developer and Data Analyst </h2>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto mb-12">
            Crafting digital experiences with clean code and creative solutions.
          </p>
          <div className="flex gap-6 justify-center mb-12">
            <motion.a 
              href="https://github.com/Srav203" 
              target="_blank"
              whileHover={{ scale: 1.1 }}
              className="text-gray-300 hover:text-white"
            >
              <Github size={24} />
            </motion.a>
            <motion.a 
              href="https://www.linkedin.com/in/sravanivemuri" 
              target="_blank"
              whileHover={{ scale: 1.1 }}
              className="text-gray-300 hover:text-white"
            >
              <Linkedin size={24} />
            </motion.a>
            <motion.a 
              href="mailto: vemurisravani60@gmail.com"
              whileHover={{ scale: 1.1 }}
              className="text-gray-300 hover:text-white"
            >
              <Mail size={24} />
            </motion.a>
          </div>
        </motion.div>
        <motion.div 
          animate={{ y: [0, 10, 0] }}
          transition={{ repeat: Infinity, duration: 2 }}
          className="absolute bottom-8"
        >
          <ChevronDown size={32} className="text-gray-400" />
        </motion.div>
      </motion.header>

      {/* About Section */}
      <motion.section 
        className="py-20 px-4"
        initial={{ opacity: 0, y: 50 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8 }}
      >
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-4 mb-8">
            <User className="text-blue-400" size={32} />
            <h2 className="text-3xl font-bold">About Me</h2>
          </div>
          <p className="text-gray-300 text-lg leading-relaxed mb-8">
            Detail-oriented Data Analyst with expertise in Python, SQL, Power BI, and cloud platforms (AWS). Hands-on experience in machine learning, generative AI applications, and data visualization. Strong problem-solving skills, stakeholder management and a passion for deriving business insights from database.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div 
              className="bg-gray-800 p-6 rounded-lg"
              whileHover={{ scale: 1.05 }}
            >
              <Code className="text-blue-400 mb-4" size={24} />
              <h3 className="text-xl font-semibold mb-2">Programming</h3>
              <p className="text-gray-400">Python, SQL, Data Structures, Generative AI</p>
            </motion.div>
            <motion.div 
              className="bg-gray-800 p-6 rounded-lg"
              whileHover={{ scale: 1.05 }}
            >
              <Briefcase className="text-blue-400 mb-4" size={24} />
              <h3 className="text-xl font-semibold mb-2">Data Visualization Tools</h3>
              <p className="text-gray-400">Power BI, MS Excel</p>
            </motion.div>
            <motion.div 
              className="bg-gray-800 p-6 rounded-lg"
              whileHover={{ scale: 1.05 }}
            >
              <ExternalLink className="text-blue-400 mb-4" size={24} />
              <h3 className="text-xl font-semibold mb-2">Soft Skills</h3>
              <p className="text-gray-400">Strong verbal and written communication skills, Problem-solving, Stakeholder Management,</p>
            </motion.div>
          </div>
        </div>
      </motion.section>

      {/* Projects Section */}
      <motion.section 
        className="py-20 px-4 bg-gray-900"
        initial={{ opacity: 0, y: 50 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8 }}
      >
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-4 mb-12">
            <Code className="text-blue-400" size={32} />
            <h2 className="text-3xl font-bold">Featured Projects</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {[1].map((project) => (
              <motion.div 
                key={project}
                className="bg-gray-800 rounded-lg overflow-hidden"
                whileHover={{ y: -10 }}
              >
                <img 
            src="https://www.dropbox.com/scl/fi/mvjfyttuvycmuvorpysut/download-1.jpeg?rlkey=lg2p7dd4wnszbi4skto8i0wt8&raw=1"
                  alt={`Project ${project}`}
                  className="w-full max-w-[300px] h-auto mx-auto"
                />
                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-2">Gun-Detection Using OpenCV {project}</h3>
                  <p className="text-gray-400 mb-4">
                    Developed a real-time gun detection system using OpenCV, Haar Cascade, and Python to identify firearms in
video streams.
• Implemented object detection, image processing, and bounding box visualization for enhanced security
surveillance.
• Integrated live webcam feed processing with automated alerts for potential threats
                  </p>
                  <div className="flex gap-4">
                    <motion.a 
                      href="#"
                      className="text-blue-400 hover:text-blue-300 flex items-center gap-2"
                      whileHover={{ x: 5 }}
                    >
                      <Github size={20} />
                      <span>Code</span>
                    </motion.a>
                    <motion.a 
                      href="https://github.com/Srav203/GunDetection/tree/main"
               className="GunDetection"
                      whileHover={{ x: 5 }}
                    >
                      <ExternalLink size={20} />
                      <span>Demo</span>
                    </motion.a>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
          
        </div>
      </motion.section>

      {/* Contact Section */}
      <motion.footer 
        className="py-20 px-4"
        initial={{ opacity: 0, y: 50 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8 }}
      >
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-8">Let's Connect</h2>
          <motion.button
            className="bg-blue-500 hover:bg-blue-600 text-white px-8 py-3 rounded-full font-semibold"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Get in Touch
          </motion.button>
          <div className="mt-12 text-gray-400">
            <p>© 2024 Sravani Vemuri. All rights reserved.</p>
          </div>
        </div>
      </motion.footer>
    </div>
  );
}

export default App;